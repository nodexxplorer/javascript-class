 const data =
[
{
    "id": 1,
    "name": "Mr. Lawson",
    "company": "Mita school",
    "position": "Founder",
    "address": "15 ekpenyong street",
    "state": "Akwa Ibom ",
    "country": "Nigeria",
    "photo": "/public/boss.jpg"
    
  },
  {
    "id": 2,
    "name": "Mr. Uwem",
    "company": "Mita school",
    "position": "Manager/Tutor",
    "address": "15 ekpenyong street",
    "state": "Akwa Ibom ",
    "country": "Nigeria",
    "photo": "/public/mruwem.jpg"
  },
  {
    "id": 3,
    "name": "Mr Jahno Paul",
    "company": "Mita school",
    "position": "Staff",
    "address": "15 ekpenyong street",
    "state": "Akwa Ibom ",
    "country": "Nigeria",
    "photo": "/public/jahno.jpg"
  },
  
  {
    "id": 4,
    "name": "Miss Sifon Bassey",
    "company": "Mita school",
    "position": "Staff",
    "address": "15 ekpenyong street",
    "state": "Akwa Ibom ",
    "country": "Nigeria",
    "photo": "/public/sifon.jpg"
  },
  {
    "id": 5,
    "name": "Mr Esaint Michael",
    "company": "Mita school",
    "position": "Staff/Tutor",
    "address": "15 ekpenyong street",
    "state": "Akwa Ibom ",
    "country": "Nigeria",
    "photo": "/public/esaint.jpg"
  },
  {
    "id": 6,
    "name": "Mr Chukwuemeka Michael",
    "company": "Mita school",
    "position": "Tutor",
    "address": "15 ekpenyong street",
    "state": "Akwa Ibom ",
    "country": "Nigeria",
    "photo": "/public/chuk.jpg"
  },
  {
    "id": 7,
    "name": "Mr Otu-ekong",
    "company": "Mita school",
    "position": "Tutor",
    "address": "15 ekpenyong street",
    "state": "Akwa Ibom ",
    "country": "Nigeria",
    "photo": "/public/otu.jpg"
  },
    {
    "id": 8,
    "name": "Miss Keziah",
    "company": "Mita school",
    "position": "Staff",
    "address": "15 ekpenyong street",
    "state": "Akwa Ibom ",
    "country": "Nigeria",
    "photo": "/public/keziah.jpg"
  },
    {
    "id": 9,
    "name": "Miss shalom",
    "company": "Mita school",
    "position": "Staff",
    "address": "15 ekpenyong street",
    "state": "Akwa Ibom ",
    "country": "Nigeria",
    "photo": "/public/shalom.jpg"
  },
]

export default data;